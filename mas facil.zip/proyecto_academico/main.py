"""
main.py  ·  LA VISTA
Aquí solo se muestra y se pide información: print(), input() y los menús.
Aquí NO se validan reglas del negocio y NO se abren archivos:
eso lo hace el Controlador (views.py).

CÓMO CAMBIAR COSAS:
  - Agregar una opción a un menú -> escribir su función y sumar una línea
    al diccionario del menú (MENU_ESTUDIANTES, MENU_MATERIAS, MENU_MATRICULAS)
  - Cambiar un texto o una pregunta -> buscar el input() o print() y editarlo
"""

from shared.herramientas import (
    imprimir_titulo, imprimir_exito, imprimir_error, imprimir_info, confirmar
)
from views import EstudianteController, MateriaController, MatriculaController

# Se crea UN solo controlador de cada tipo y se usan en todo el programa.
# A las matrículas se les pasan los MISMOS estudiantes y materias.
estudiantes = EstudianteController()
materias = MateriaController()
matriculas = MatriculaController(estudiantes, materias)


# =====================================================================
# FUNCIONES DE AYUDA (las usan todos los menús)
# =====================================================================

def pausa():
    input("\nPresione Enter para continuar...")


def pedir_entero(pregunta):
    """Pide un número entero. Si escriben otra cosa, devuelve None."""
    try:
        return int(input(pregunta))
    except ValueError:
        return None


def mostrar_resultado(exito, mensaje):
    # Los controladores devuelven (exito, mensaje): verde si salió bien, rojo si no
    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)


def mostrar_lista(objetos, mensaje_vacio="No hay registros todavía."):
    """Sirve para estudiantes, materias y matrículas.
    Hace print(objeto) y cada modelo se muestra a su manera (POLIMORFISMO)."""
    if not objetos:
        imprimir_info(mensaje_vacio)
        return
    for objeto in objetos:
        print(f"  {objeto}")
    imprimir_info(f"Total: {len(objetos)}")


def mostrar_detalle(objeto):
    # Recorre el diccionario del objeto e imprime cada clave con su valor
    for clave, valor in objeto.a_diccionario().items():
        nombre = clave.replace("_", " ").capitalize()
        print(f"  {nombre:<16}: {valor}")


# =====================================================================
# MENÚ DE ESTUDIANTES
# =====================================================================

def crear_estudiante():
    imprimir_titulo("CREAR ESTUDIANTE")
    datos = {
        "nombre": input("Nombre: "),
        "apellido": input("Apellido: "),
        "email": input("Email: "),
        "carnet": input("Carnet: "),
        "carrera": input("Carrera: "),
    }
    exito, mensaje = estudiantes.crear(datos)
    mostrar_resultado(exito, mensaje)
    pausa()


def listar_estudiantes():
    imprimir_titulo("ESTUDIANTES")
    mostrar_lista(estudiantes.leer(), "Todavía no hay estudiantes.")
    pausa()


def buscar_estudiante():
    imprimir_titulo("BUSCAR ESTUDIANTE")
    termino = input("Nombre, email, carnet o carrera: ")
    encontrados = estudiantes.buscar(termino)
    mostrar_lista(encontrados, f"Ningún estudiante coincide con '{termino}'.")
    pausa()


def ver_estudiante():
    imprimir_titulo("VER ESTUDIANTE POR ID")
    id_estudiante = pedir_entero("Id: ")
    estudiante = estudiantes.obtener(id_estudiante)
    if estudiante is None:
        imprimir_error("No encontrado")
    else:
        mostrar_detalle(estudiante)
    pausa()


def actualizar_estudiante():
    imprimir_titulo("ACTUALIZAR ESTUDIANTE")
    id_estudiante = pedir_entero("Id: ")
    estudiante = estudiantes.obtener(id_estudiante)
    if estudiante is None:
        imprimir_error("No encontrado")
        pausa()
        return

    imprimir_info(f"Editando: {estudiante.etiqueta()}")
    print("Deje en blanco lo que no quiera cambiar.\n")

    # Solo guardo en "cambios" los campos que el usuario escribió
    cambios = {}
    for campo in ("nombre", "apellido", "email", "carnet", "carrera"):
        valor_actual = getattr(estudiante, campo)
        nuevo = input(f"{campo.capitalize()} [{valor_actual}]: ").strip()
        if nuevo != "":
            cambios[campo] = nuevo

    exito, mensaje = estudiantes.actualizar(id_estudiante, cambios)
    mostrar_resultado(exito, mensaje)
    pausa()


def eliminar_estudiante():
    imprimir_titulo("ELIMINAR ESTUDIANTE")
    id_estudiante = pedir_entero("Id: ")
    estudiante = estudiantes.obtener(id_estudiante)
    if estudiante is None:
        imprimir_error("No encontrado")
        pausa()
        return

    imprimir_info(f"Se eliminará: {estudiante.etiqueta()}")
    if confirmar("¿Confirma?"):
        exito, mensaje = estudiantes.eliminar(id_estudiante)
        mostrar_resultado(exito, mensaje)
    else:
        imprimir_info("Operación cancelada")
    pausa()


# =====================================================================
# MENÚ DE MATERIAS
# =====================================================================

def crear_materia():
    imprimir_titulo("CREAR MATERIA")
    datos = {
        "nombre": input("Nombre: "),
        "codigo": input("Código (ej. MAT101): "),
        "creditos": input("Créditos: "),
        "cupos": input("Cupos (Enter = máximo): "),
    }
    exito, mensaje = materias.crear(datos)
    mostrar_resultado(exito, mensaje)
    pausa()


def listar_materias():
    imprimir_titulo("MATERIAS")
    mostrar_lista(materias.leer(), "Todavía no hay materias.")
    pausa()


def buscar_materia():
    imprimir_titulo("BUSCAR MATERIA")
    termino = input("Nombre o código: ")
    encontradas = materias.buscar(termino)
    mostrar_lista(encontradas, "Sin coincidencias.")
    pausa()


def ver_materia():
    imprimir_titulo("VER MATERIA POR ID")
    id_materia = pedir_entero("Id: ")
    materia = materias.obtener(id_materia)
    if materia is None:
        imprimir_error("No encontrado")
    else:
        mostrar_detalle(materia)
    pausa()


def actualizar_materia():
    imprimir_titulo("ACTUALIZAR MATERIA")
    id_materia = pedir_entero("Id: ")
    materia = materias.obtener(id_materia)
    if materia is None:
        imprimir_error("No encontrado")
        pausa()
        return

    imprimir_info(f"Editando: {materia.etiqueta()}")
    print("Deje en blanco lo que no quiera cambiar.\n")

    cambios = {}
    for campo in ("nombre", "codigo", "creditos", "cupos"):
        valor_actual = getattr(materia, campo)
        nuevo = input(f"{campo.capitalize()} [{valor_actual}]: ").strip()
        if nuevo != "":
            cambios[campo] = nuevo

    exito, mensaje = materias.actualizar(id_materia, cambios)
    mostrar_resultado(exito, mensaje)
    pausa()


def eliminar_materia():
    imprimir_titulo("ELIMINAR MATERIA")
    id_materia = pedir_entero("Id: ")
    materia = materias.obtener(id_materia)
    if materia is None:
        imprimir_error("No encontrado")
        pausa()
        return

    imprimir_info(f"Se eliminará: {materia.etiqueta()}")
    if confirmar("¿Confirma?"):
        exito, mensaje = materias.eliminar(id_materia)
        mostrar_resultado(exito, mensaje)
    else:
        imprimir_info("Operación cancelada")
    pausa()


# =====================================================================
# MENÚ DE MATRÍCULAS
# =====================================================================

def matricular():
    imprimir_titulo("MATRICULAR")
    imprimir_info("Estudiantes:")
    mostrar_lista(estudiantes.leer())
    imprimir_info("Materias:")
    mostrar_lista(materias.leer())

    id_estudiante = pedir_entero("\nId del estudiante: ")
    id_materia = pedir_entero("Id de la materia: ")
    periodo = input("Periodo (ej. 2026-1): ")

    if id_estudiante is None or id_materia is None:
        imprimir_error("Los ids deben ser números enteros")
        pausa()
        return

    datos = {
        "estudiante_id": id_estudiante,
        "materia_id": id_materia,
        "periodo": periodo,
    }
    exito, mensaje = matriculas.crear(datos)
    mostrar_resultado(exito, mensaje)
    pausa()


def listar_matriculas():
    imprimir_titulo("MATRÍCULAS")
    mostrar_lista(matriculas.leer(), "Todavía no hay matrículas.")
    pausa()


def registrar_nota():
    imprimir_titulo("REGISTRAR NOTA")
    id_matricula = pedir_entero("Id de la matrícula: ")
    if id_matricula is None:
        imprimir_error("El id debe ser un número entero")
        pausa()
        return

    nota = input("Nota (0 a 20): ")
    exito, mensaje = matriculas.registrar_nota(id_matricula, nota)
    mostrar_resultado(exito, mensaje)
    pausa()


def ver_certificado():
    imprimir_titulo("CERTIFICADO")
    id_matricula = pedir_entero("Id de la matrícula: ")
    texto = matriculas.certificado(id_matricula)
    if texto is None:
        imprimir_error("No existe esa matrícula")
    else:
        print(texto)
    pausa()


def retirar_matricula():
    imprimir_titulo("RETIRAR MATRÍCULA")
    id_matricula = pedir_entero("Id de la matrícula: ")
    if id_matricula is None:
        imprimir_error("El id debe ser un número entero")
        pausa()
        return

    if confirmar("Se liberará el cupo. ¿Confirma?"):
        exito, mensaje = matriculas.retirar_matricula(id_matricula)
        mostrar_resultado(exito, mensaje)
    else:
        imprimir_info("Operación cancelada")
    pausa()


def ver_promedio():
    imprimir_titulo("PROMEDIO DE ESTUDIANTE")
    id_estudiante = pedir_entero("Id del estudiante: ")
    estudiante = estudiantes.obtener(id_estudiante)
    if estudiante is None:
        imprimir_error("No encontrado")
        pausa()
        return

    promedio = matriculas.promedio_de_estudiante(id_estudiante)
    if promedio is None:
        imprimir_info(f"{estudiante.nombre_completo()} todavía no tiene notas registradas.")
    else:
        imprimir_info(f"Promedio de {estudiante.nombre_completo()}: {promedio}")
    pausa()


# =====================================================================
# RESUMEN
# =====================================================================

def resumen():
    imprimir_titulo("RESUMEN")
    carreras = estudiantes.carreras()
    sin_cupo = materias.materias_sin_cupo()

    print(f"  Estudiantes   : {len(estudiantes.leer())}")
    if len(carreras) == 0:
        print("  Carreras      : -")
    else:
        print(f"  Carreras      : {', '.join(carreras)}")

    print(f"  Materias      : {len(materias.leer())}")
    if len(sin_cupo) == 0:
        print("  Sin cupo      : ninguna")
    else:
        codigos = []
        for materia in sin_cupo:
            codigos.append(materia.codigo)
        print(f"  Sin cupo      : {', '.join(codigos)}")

    print(f"  Matrículas    : {len(matriculas.leer())}")
    print(f"  Aprobadas     : {matriculas.total_aprobadas()}")
    pausa()


# =====================================================================
# MENÚS
# Cada menú es un DICCIONARIO:  "tecla": ("texto que se ve", función)
# Para agregar una opción, agrega una línea nueva aquí.
# La función None significa "Volver".
# =====================================================================

MENU_ESTUDIANTES = {
    "1": ("Crear estudiante", crear_estudiante),
    "2": ("Ver todos", listar_estudiantes),
    "3": ("Buscar", buscar_estudiante),
    "4": ("Ver por id", ver_estudiante),
    "5": ("Actualizar", actualizar_estudiante),
    "6": ("Eliminar", eliminar_estudiante),
    "0": ("Volver", None),
}

MENU_MATERIAS = {
    "1": ("Crear materia", crear_materia),
    "2": ("Ver todas", listar_materias),
    "3": ("Buscar", buscar_materia),
    "4": ("Ver por id", ver_materia),
    "5": ("Actualizar", actualizar_materia),
    "6": ("Eliminar", eliminar_materia),
    "0": ("Volver", None),
}

MENU_MATRICULAS = {
    "1": ("Matricular", matricular),
    "2": ("Ver todas", listar_matriculas),
    "3": ("Registrar nota", registrar_nota),
    "4": ("Ver certificado", ver_certificado),
    "5": ("Retirar matrícula", retirar_matricula),
    "6": ("Promedio de un estudiante", ver_promedio),
    "0": ("Volver", None),
}


def ejecutar_menu(titulo, opciones):
    """Un solo bucle que sirve para los tres submenús."""
    while True:
        imprimir_titulo(titulo)
        for tecla, (texto, funcion) in opciones.items():
            print(f"  {tecla}. {texto}")
        print()

        tecla = input("Opción: ").strip()
        if tecla not in opciones:
            imprimir_error("Opción no válida")
            pausa()
            continue

        texto, funcion = opciones[tecla]
        if funcion is None:   # eligió "Volver"
            break
        funcion()


def main():
    while True:
        imprimir_titulo("SISTEMA ACADÉMICO")
        print("  1. Estudiantes")
        print("  2. Materias")
        print("  3. Matrículas")
        print("  4. Resumen")
        print("  0. Salir\n")

        tecla = input("Opción: ").strip()
        if tecla == "1":
            ejecutar_menu("ESTUDIANTES", MENU_ESTUDIANTES)
        elif tecla == "2":
            ejecutar_menu("MATERIAS", MENU_MATERIAS)
        elif tecla == "3":
            ejecutar_menu("MATRÍCULAS", MENU_MATRICULAS)
        elif tecla == "4":
            resumen()
        elif tecla == "0":
            imprimir_info("¡Hasta luego! 👋")
            break
        else:
            imprimir_error("Opción no válida")
            pausa()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nPrograma interrumpido por el usuario.")
