"""
views.py  ·  EL CONTROLADOR
Aquí están las reglas del sistema: validar, buscar, crear, actualizar, eliminar.
Aquí NO se usa print() ni input(): este archivo no habla con el usuario.
Cada operación devuelve la tupla (exito, mensaje) o datos.

CÓMO CAMBIAR COSAS (casi todo está en las constantes de abajo):
  - Cambiar créditos permitidos        -> CREDITOS_MINIMO / CREDITOS_MAXIMO
  - Campos por los que se busca        -> CAMPOS_BUSCABLES_...
  - Campos obligatorios al crear       -> CAMPOS_OBLIGATORIOS_...
  - Dónde se guardan los archivos      -> ARCHIVO_...
  (el cupo máximo y la nota de aprobación están en models.py, clase Materia)
"""

from abc import ABC, abstractmethod

from models import Estudiante, Materia, Matricula
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido


# =====================================================================
# CONSTANTES QUE SE PUEDEN CAMBIAR
# Son TUPLAS porque son datos fijos que no deben modificarse mientras
# el programa corre.
# =====================================================================
ARCHIVO_ESTUDIANTES = "data/estudiantes.json"
ARCHIVO_MATERIAS = "data/materias.json"
ARCHIVO_MATRICULAS = "data/matriculas.json"

CREDITOS_MINIMO = 1
CREDITOS_MAXIMO = 10

CAMPOS_OBLIGATORIOS_ESTUDIANTE = ("nombre", "apellido", "email", "carnet")
CAMPOS_PERMITIDOS_ESTUDIANTE = ("nombre", "apellido", "email", "carnet", "carrera")
CAMPOS_BUSCABLES_ESTUDIANTE = ("nombre", "apellido", "email", "carnet", "carrera")

CAMPOS_OBLIGATORIOS_MATERIA = ("nombre", "codigo", "creditos")
CAMPOS_PERMITIDOS_MATERIA = ("nombre", "codigo", "creditos", "cupos")
CAMPOS_BUSCABLES_MATERIA = ("nombre", "codigo")

CAMPOS_BUSCABLES_MATRICULA = ("periodo",)


# =====================================================================
# FUNCIÓN DE AYUDA
# =====================================================================
def limpiar(datos, campo):
    """Devuelve el texto de un campo sin espacios. Si no existe, devuelve ''."""
    return str(datos.get(campo, "")).strip()


# =====================================================================
# CLASE BASE ABSTRACTA
# Solo dice QUÉ métodos debe tener todo controlador. No tiene código.
# Si a un controlador le falta alguno, Python no deja crearlo.
# =====================================================================
class CrudBase(ABC):

    @abstractmethod
    def leer(self):
        pass

    @abstractmethod
    def obtener(self, id_registro):
        pass

    @abstractmethod
    def buscar(self, texto):
        pass

    @abstractmethod
    def siguiente(self):
        pass

    @abstractmethod
    def crear(self, datos):
        pass

    @abstractmethod
    def actualizar(self, id_registro, datos):
        pass

    @abstractmethod
    def eliminar(self, id_registro):
        pass


# =====================================================================
# CONTROLADOR DE ESTUDIANTES
# =====================================================================
class EstudianteController(CrudBase):

    def __init__(self, archivo=ARCHIVO_ESTUDIANTES):
        self.gestor = GestorJSON(archivo)

        # LISTA con los objetos Estudiante. Es la colección principal.
        # Leemos el JSON una vez y convertimos cada diccionario en objeto.
        self.lista = []
        for datos in self.gestor.leer():
            estudiante = Estudiante.desde_diccionario(datos)
            self.lista.append(estudiante)

    def guardar(self):
        # Convierte cada objeto en diccionario y reescribe el archivo
        datos = []
        for estudiante in self.lista:
            datos.append(estudiante.a_diccionario())
        self.gestor.guardar(datos)

    def validar(self, datos, id_actual=None):
        """Devuelve un mensaje de error, o None si todo está bien.
        id_actual es el id del estudiante que se está editando (None al crear)."""

        # 1) Al crear, los campos obligatorios no pueden estar vacíos
        if id_actual is None:
            for campo in CAMPOS_OBLIGATORIOS_ESTUDIANTE:
                if limpiar(datos, campo) == "":
                    return f"El campo {campo} es obligatorio"

        # 2) Email válido y no repetido
        if "email" in datos:
            email = limpiar(datos, "email").lower()
            if not es_email_valido(email):
                return f"Email inválido: '{email}'"

            # CONJUNTO de emails de los OTROS estudiantes.
            # Elegí set porque preguntar "email in emails_usados" es instantáneo.
            emails_usados = set()
            for otro in self.lista:
                if otro.id != id_actual:
                    emails_usados.add(otro.email)
            if email in emails_usados:
                return "Ese email ya está registrado"

        # 3) Carnet no vacío y no repetido
        if "carnet" in datos:
            carnet = limpiar(datos, "carnet").upper()
            if carnet == "":
                return "El carnet no puede quedar vacío"

            # CONJUNTO de carnets de los OTROS estudiantes (mismo motivo)
            carnets_usados = set()
            for otro in self.lista:
                if otro.id != id_actual:
                    carnets_usados.add(otro.carnet)
            if carnet in carnets_usados:
                return f"El carnet {carnet} ya está registrado"

        return None   # None = no hubo errores

    def leer(self):
        return self.lista

    def obtener(self, id_estudiante):
        for estudiante in self.lista:
            if estudiante.id == id_estudiante:
                return estudiante
        return None

    def buscar(self, texto):
        texto = texto.strip().lower()
        encontrados = []
        if texto == "":
            return encontrados

        for estudiante in self.lista:
            # Reviso cada campo buscable (la TUPLA de arriba)
            for campo in CAMPOS_BUSCABLES_ESTUDIANTE:
                valor = str(getattr(estudiante, campo)).lower()
                if texto in valor:
                    encontrados.append(estudiante)
                    break   # ya coincidió: no lo agrego dos veces
        return encontrados

    def siguiente(self):
        # El próximo id es el mayor que existe + 1
        mayor = 0
        for estudiante in self.lista:
            if estudiante.id > mayor:
                mayor = estudiante.id
        return mayor + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error

        estudiante = Estudiante(
            self.siguiente(),
            limpiar(datos, "nombre").title(),
            limpiar(datos, "apellido").title(),
            limpiar(datos, "email").lower(),
            limpiar(datos, "carnet").upper(),
            limpiar(datos, "carrera").title(),
        )
        self.lista.append(estudiante)
        self.guardar()
        return True, f"Estudiante creado: {estudiante.etiqueta()}"

    def actualizar(self, id_estudiante, datos):
        estudiante = self.obtener(id_estudiante)
        if estudiante is None:
            return False, f"No existe un estudiante con id {id_estudiante}"
        if not datos:
            return False, "No se indicó ningún cambio"

        # DIFERENCIA de conjuntos: los campos que llegan menos los permitidos.
        # Lo que sobre son campos que un estudiante no tiene.
        desconocidos = set(datos) - set(CAMPOS_PERMITIDOS_ESTUDIANTE)
        if desconocidos:
            return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"

        # Valido ANTES de tocar el objeto: si algo falla, no cambia nada
        error = self.validar(datos, id_estudiante)
        if error:
            return False, error

        if "nombre" in datos:
            estudiante.nombre = limpiar(datos, "nombre").title()
        if "apellido" in datos:
            estudiante.apellido = limpiar(datos, "apellido").title()
        if "email" in datos:
            estudiante.email = limpiar(datos, "email").lower()
        if "carnet" in datos:
            estudiante.carnet = limpiar(datos, "carnet").upper()
        if "carrera" in datos:
            estudiante.carrera = limpiar(datos, "carrera").title()

        self.guardar()
        return True, f"Estudiante {id_estudiante} actualizado"

    def eliminar(self, id_estudiante):
        estudiante = self.obtener(id_estudiante)
        if estudiante is None:
            return False, f"No existe un estudiante con id {id_estudiante}"

        self.lista.remove(estudiante)
        self.guardar()
        return True, f"Estudiante {id_estudiante} eliminado"

    # --- método propio de estudiantes ---
    def carreras(self):
        """Devuelve las carreras SIN repetir y ordenadas."""
        # CONJUNTO: si dos estudiantes tienen la misma carrera, queda una sola
        carreras = set()
        for estudiante in self.lista:
            if estudiante.carrera != "":
                carreras.add(estudiante.carrera)
        return sorted(carreras)   # sorted() lo convierte en lista ordenada


# =====================================================================
# CONTROLADOR DE MATERIAS
# =====================================================================
class MateriaController(CrudBase):

    def __init__(self, archivo=ARCHIVO_MATERIAS):
        self.gestor = GestorJSON(archivo)

        self.lista = []
        for datos in self.gestor.leer():
            materia = Materia.desde_diccionario(datos)
            self.lista.append(materia)

    def guardar(self):
        datos = []
        for materia in self.lista:
            datos.append(materia.a_diccionario())
        self.gestor.guardar(datos)

    def validar(self, datos, id_actual=None):
        # 1) Obligatorios (solo al crear)
        if id_actual is None:
            for campo in CAMPOS_OBLIGATORIOS_MATERIA:
                if limpiar(datos, campo) == "":
                    return f"El campo {campo} es obligatorio"

        # 2) Código no vacío y no repetido
        if "codigo" in datos:
            codigo = limpiar(datos, "codigo").upper()
            if codigo == "":
                return "El código no puede quedar vacío"

            # CONJUNTO de códigos de las OTRAS materias (búsqueda instantánea)
            codigos_usados = set()
            for otra in self.lista:
                if otra.id != id_actual:
                    codigos_usados.add(otra.codigo)
            if codigo in codigos_usados:
                return f"El código {codigo} ya existe"

        # 3) Créditos: entero entre el mínimo y el máximo
        if "creditos" in datos:
            creditos = limpiar(datos, "creditos")
            if not creditos.isdigit():
                return f"Los créditos deben ser un entero entre {CREDITOS_MINIMO} y {CREDITOS_MAXIMO}"
            if int(creditos) < CREDITOS_MINIMO or int(creditos) > CREDITOS_MAXIMO:
                return f"Los créditos deben ser un entero entre {CREDITOS_MINIMO} y {CREDITOS_MAXIMO}"

        # 4) Cupos: entero entre 0 y el máximo (puede venir vacío al crear)
        if "cupos" in datos:
            cupos = limpiar(datos, "cupos")
            if cupos != "":
                if not cupos.isdigit() or int(cupos) > Materia.CUPOS_MAXIMOS:
                    return f"Los cupos deben ser un entero entre 0 y {Materia.CUPOS_MAXIMOS}"

        return None

    def leer(self):
        return self.lista

    def obtener(self, id_materia):
        for materia in self.lista:
            if materia.id == id_materia:
                return materia
        return None

    def buscar(self, texto):
        texto = texto.strip().lower()
        encontradas = []
        if texto == "":
            return encontradas

        for materia in self.lista:
            for campo in CAMPOS_BUSCABLES_MATERIA:
                valor = str(getattr(materia, campo)).lower()
                if texto in valor:
                    encontradas.append(materia)
                    break
        return encontradas

    def siguiente(self):
        mayor = 0
        for materia in self.lista:
            if materia.id > mayor:
                mayor = materia.id
        return mayor + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error

        # Si no escriben los cupos, la materia empieza con el máximo
        cupos = limpiar(datos, "cupos")
        if cupos == "":
            cupos = Materia.CUPOS_MAXIMOS

        materia = Materia(
            self.siguiente(),
            limpiar(datos, "nombre").title(),
            limpiar(datos, "codigo").upper(),
            int(limpiar(datos, "creditos")),
            int(cupos),
        )
        self.lista.append(materia)
        self.guardar()
        return True, f"Materia creada: {materia.etiqueta()}"

    def actualizar(self, id_materia, datos):
        materia = self.obtener(id_materia)
        if materia is None:
            return False, f"No existe una materia con id {id_materia}"
        if not datos:
            return False, "No se indicó ningún cambio"

        desconocidos = set(datos) - set(CAMPOS_PERMITIDOS_MATERIA)
        if desconocidos:
            return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"

        error = self.validar(datos, id_materia)
        if error:
            return False, error

        if "nombre" in datos:
            materia.nombre = limpiar(datos, "nombre").title()
        if "codigo" in datos:
            materia.codigo = limpiar(datos, "codigo").upper()
        if "creditos" in datos:
            materia.creditos = int(limpiar(datos, "creditos"))
        if "cupos" in datos:
            materia.cupos = int(limpiar(datos, "cupos"))

        self.guardar()
        return True, f"Materia {id_materia} actualizada"

    def eliminar(self, id_materia):
        materia = self.obtener(id_materia)
        if materia is None:
            return False, f"No existe una materia con id {id_materia}"

        self.lista.remove(materia)
        self.guardar()
        return True, f"Materia {id_materia} eliminada"

    # --- método propio de materias ---
    def materias_sin_cupo(self):
        sin_cupo = []
        for materia in self.lista:
            if not materia.hay_cupo():
                sin_cupo.append(materia)
        return sin_cupo


# =====================================================================
# CONTROLADOR DE MATRÍCULAS
# Este controlador USA a los otros dos, por eso los recibe al crearse.
# main.py le pasa los MISMOS controladores que usa él, para que el cupo
# que baja una matrícula se vea de inmediato en la lista de materias.
# =====================================================================
class MatriculaController(CrudBase):

    def __init__(self, estudiantes, materias, archivo=ARCHIVO_MATRICULAS):
        self.estudiantes = estudiantes
        self.materias = materias
        self.gestor = GestorJSON(archivo)

        self.lista = []
        for datos in self.gestor.leer():
            matricula = Matricula.desde_diccionario(datos)
            self.lista.append(matricula)

    def guardar(self):
        datos = []
        for matricula in self.lista:
            datos.append(matricula.a_diccionario())
        self.gestor.guardar(datos)

    def validar(self, datos):
        # 1) Los ids deben ser números enteros
        try:
            estudiante_id = int(datos.get("estudiante_id", 0))
            materia_id = int(datos.get("materia_id", 0))
        except (TypeError, ValueError):
            return "estudiante_id y materia_id deben ser números enteros"

        # 2) El periodo es obligatorio
        periodo = limpiar(datos, "periodo")
        if periodo == "":
            return "El periodo es obligatorio (ej. 2026-1)"

        # 3) El estudiante debe existir
        estudiante = self.estudiantes.obtener(estudiante_id)
        if estudiante is None:
            return f"No existe un estudiante con id {estudiante_id}"

        # 4) La materia debe existir y tener cupo
        materia = self.materias.obtener(materia_id)
        if materia is None:
            return f"No existe una materia con id {materia_id}"
        if not materia.hay_cupo():
            return f"La materia {materia.codigo} no tiene cupos disponibles"

        # 5) No matricular dos veces al mismo estudiante en la misma materia
        #    y periodo. Comparo las TRES cosas juntas.
        #    CONJUNTO de TUPLAS: cada tupla (estudiante, materia, periodo)
        #    es una matrícula. Uso tupla porque una lista no puede ir
        #    dentro de un conjunto.
        existentes = set()
        for m in self.lista:
            existentes.add((m.estudiante_id, m.materia_id, m.periodo))
        if (estudiante_id, materia_id, periodo) in existentes:
            return (f"{estudiante.nombre_completo()} ya está matriculado en "
                    f"{materia.codigo} en el periodo {periodo}")

        return None

    def leer(self):
        return self.lista

    def obtener(self, id_matricula):
        for matricula in self.lista:
            if matricula.id == id_matricula:
                return matricula
        return None

    def buscar(self, texto):
        # Las matrículas se buscan por periodo, ej: "2026-1"
        texto = texto.strip()
        encontradas = []
        if texto == "":
            return encontradas

        for matricula in self.lista:
            for campo in CAMPOS_BUSCABLES_MATRICULA:
                valor = str(getattr(matricula, campo))
                if texto in valor:
                    encontradas.append(matricula)
                    break
        return encontradas

    def siguiente(self):
        mayor = 0
        for matricula in self.lista:
            if matricula.id > mayor:
                mayor = matricula.id
        return mayor + 1

    def crear(self, datos):
        # datos = {"estudiante_id": 1, "materia_id": 1, "periodo": "2026-1"}
        error = self.validar(datos)
        if error:
            return False, error

        materia = self.materias.obtener(int(datos["materia_id"]))
        matricula = Matricula(
            self.siguiente(),
            int(datos["estudiante_id"]),
            materia.id,
            limpiar(datos, "periodo"),
        )

        materia.ocupar_cupo()     # la materia tiene un cupo menos
        self.materias.guardar()   # guardo el cupo nuevo en materias.json
        self.lista.append(matricula)
        self.guardar()            # guardo la matrícula en matriculas.json
        return True, f"Matrícula {matricula.id} registrada ({materia.codigo}, {matricula.periodo})"

    def registrar_nota(self, id_matricula, nota):
        matricula = self.obtener(id_matricula)
        if matricula is None:
            return False, f"No existe la matrícula {id_matricula}"

        # es_nota_valida es el método ESTÁTICO de Materia
        if not Materia.es_nota_valida(nota):
            return False, f"Nota inválida: '{nota}' (debe estar entre 0 y 20)"

        matricula.nota = float(nota)
        self.guardar()
        return True, f"Nota {matricula.nota:g} registrada: {matricula.estado()}"

    def actualizar(self, id_matricula, datos):
        # En una matrícula solo se puede cambiar la nota
        if "nota" not in datos or len(datos) != 1:
            return False, "En una matrícula solo se puede actualizar la nota"
        return self.registrar_nota(id_matricula, datos["nota"])

    def eliminar(self, id_matricula):
        """Retirar una matrícula: se borra y el cupo vuelve a la materia."""
        matricula = self.obtener(id_matricula)
        if matricula is None:
            return False, f"No existe la matrícula {id_matricula}"

        materia = self.materias.obtener(matricula.materia_id)
        if materia is not None:
            materia.liberar_cupo()
            self.materias.guardar()

        self.lista.remove(matricula)
        self.guardar()
        return True, f"Matrícula {id_matricula} retirada y cupo liberado"

    def retirar_matricula(self, id_matricula):
        # Es el mismo eliminar(), con el nombre que pide la tarea
        return self.eliminar(id_matricula)

    # --- métodos propios de matrículas ---
    def certificado(self, id_matricula):
        matricula = self.obtener(id_matricula)
        if matricula is None:
            return None

        # DICCIONARIOS ÍNDICE {id: objeto}.
        # Con ellos encuentro un estudiante o una materia por su id
        # directamente, sin recorrer toda la lista.
        estudiantes_por_id = {}
        for estudiante in self.estudiantes.leer():
            estudiantes_por_id[estudiante.id] = estudiante

        materias_por_id = {}
        for materia in self.materias.leer():
            materias_por_id[materia.id] = materia

        estudiante = estudiantes_por_id.get(matricula.estudiante_id)
        materia = materias_por_id.get(matricula.materia_id)

        if estudiante is None:
            nombre = "eliminado"
            carnet = "-"
        else:
            nombre = estudiante.nombre_completo()
            carnet = estudiante.carnet

        if matricula.nota is None:
            nota = "sin registrar"
        else:
            nota = f"{matricula.nota:g}"

        texto = f"CERTIFICADO #{matricula.id}   periodo: {matricula.periodo}\n"
        texto += f"Estudiante: {nombre}   ({carnet})\n"
        if materia is None:
            texto += "Materia   : eliminada\n"
        else:
            texto += (f"Materia   : {materia.nombre}   ({materia.codigo}) · "
                      f"{materia.creditos} créditos\n")
        texto += "-" * 42 + "\n"
        texto += f"Nota      : {nota}\n"
        texto += f"Estado    : {matricula.estado()}"
        return texto

    def matriculas_por_estudiante(self):
        """Devuelve {estudiante_id: [sus matrículas]}."""
        # DICCIONARIO DE LISTAS: la clave es el id del estudiante y el valor
        # es la lista de todas sus matrículas.
        agrupadas = {}
        for matricula in self.lista:
            # setdefault: si el estudiante todavía no está, crea su lista vacía.
            # Después, con append, agrego la matrícula a esa lista.
            agrupadas.setdefault(matricula.estudiante_id, []).append(matricula)
        return agrupadas

    def promedio_de_estudiante(self, id_estudiante):
        """Promedio de las notas ya registradas. None si no tiene ninguna."""
        agrupadas = self.matriculas_por_estudiante()
        matriculas = agrupadas.get(id_estudiante, [])

        suma = 0
        cantidad = 0
        for matricula in matriculas:
            if matricula.nota is not None:
                suma = suma + matricula.nota
                cantidad = cantidad + 1

        if cantidad == 0:
            return None
        return round(suma / cantidad, 2)

    def total_aprobadas(self):
        total = 0
        for matricula in self.lista:
            if matricula.esta_aprobada():
                total = total + 1
        return total
