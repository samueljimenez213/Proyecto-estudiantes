"""
models.py  ·  EL MODELO
Aquí solo se define QUÉ ES cada dato (sus campos y cómo se muestra).
Aquí NO se usa input(), NO se usa print() y NO se abre ningún archivo.

Jerarquía de clases (la flecha significa "hereda de"):

    ModeloBase  <-  Persona  <-  Estudiante
    ModeloBase  <-  Materia
    ModeloBase  <-  Matricula

CÓMO CAMBIAR COSAS:
  - Agregar un campo a Estudiante  -> __init__, a_diccionario() y etiqueta()
  - Cambiar el cupo máximo o la nota para aprobar -> las constantes de Materia
"""

from datetime import date


# =====================================================================
# MODELO BASE  (NO SE TOCA)
# Lo que comparten TODOS los modelos: el id y la forma de convertirse
# en diccionario y de mostrarse.
# =====================================================================
class ModeloBase:

    def __init__(self, id_registro):
        self.id = int(id_registro)

    # ÚNICO método de clase del proyecto.
    # Convierte un diccionario (lo que viene del JSON) en un objeto.
    # "cls" es la clase que lo llamó: Estudiante, Materia o Matricula.
    # Por eso se escribe UNA sola vez y sirve para los tres.
    @classmethod
    def desde_diccionario(cls, datos):
        datos = dict(datos)               # copia, para no dañar el original
        id_registro = datos.pop("id")     # saco el id del diccionario
        return cls(id_registro, **datos)  # el resto de claves son los parámetros

    # Objeto -> diccionario (para guardarlo en el JSON)
    def a_diccionario(self):
        return {"id": self.id}

    # Cómo se ve el objeto en pantalla. Cada hijo la reescribe (POLIMORFISMO).
    def etiqueta(self):
        return f"registro {self.id}"

    # print(objeto) llama a este método, y este llama a etiqueta().
    def __str__(self):
        return f"[{self.id}] {self.etiqueta()}"


# =====================================================================
# PERSONA  (NO SE TOCA)
# Todo lo que tiene una persona: nombre, apellido y email.
# =====================================================================
class Persona(ModeloBase):

    def __init__(self, id_registro, nombre, apellido, email):
        super().__init__(id_registro)   # el padre guarda el id
        self.nombre = nombre
        self.apellido = apellido
        self.email = email

    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"

    def a_diccionario(self):
        datos = super().a_diccionario()  # trae {"id": ...}
        datos["nombre"] = self.nombre
        datos["apellido"] = self.apellido
        datos["email"] = self.email
        return datos

    def etiqueta(self):
        return self.nombre_completo()


# =====================================================================
# ESTUDIANTE  (equivale a Cliente)
# "Un estudiante ES UNA persona", por eso hereda de Persona.
# =====================================================================
class Estudiante(Persona):

    def __init__(self, id_registro, nombre, apellido, email, carnet="", carrera=""):
        # 1) el padre guarda id, nombre, apellido y email
        super().__init__(id_registro, nombre, apellido, email)
        # 2) yo guardo lo mío
        self.carnet = carnet
        self.carrera = carrera

    def a_diccionario(self):
        datos = super().a_diccionario()   # id + nombre + apellido + email
        datos["carnet"] = self.carnet     # le sumo lo propio
        datos["carrera"] = self.carrera
        return datos

    def etiqueta(self):
        # Reutilizo la del padre (nombre completo) y le agrego lo mío
        if self.carrera == "":
            carrera = "sin carrera"
        else:
            carrera = self.carrera
        return f"{super().etiqueta()} · {self.carnet} · {carrera}"


# =====================================================================
# MATERIA  (equivale a Producto)
# Aquí viven TODOS los atributos y métodos estáticos del proyecto.
# =====================================================================
class Materia(ModeloBase):

    # ---- ATRIBUTOS ESTÁTICOS ----
    # Se escriben fuera de los métodos y existen UNA sola vez para todas
    # las materias. Para cambiar una regla, cambia solo el número.
    CUPOS_MAXIMOS = 30       # máximo de cupos que puede tener una materia
    NOTA_APROBACION = 14     # desde esta nota se aprueba
    NOTA_MINIMA = 0
    NOTA_MAXIMA = 20

    def __init__(self, id_registro, nombre, codigo, creditos=0, cupos=0):
        super().__init__(id_registro)
        self.nombre = nombre
        self.codigo = codigo
        self.creditos = int(creditos)
        self.cupos = int(cupos)   # hace el papel del "stock" de Producto

    # ---- MÉTODO ESTÁTICO ----
    # No usa self ni cls: es una regla suelta que se puede preguntar
    # sin tener ninguna materia creada:  Materia.es_nota_valida("15")
    @staticmethod
    def es_nota_valida(valor):
        try:
            numero = float(valor)
        except (TypeError, ValueError):   # si no es un número
            return False
        return Materia.NOTA_MINIMA <= numero <= Materia.NOTA_MAXIMA

    # ---- MÉTODOS DE INSTANCIA (usan self: los datos de ESTA materia) ----
    def hay_cupo(self):
        return self.cupos > 0

    def ocupar_cupo(self):
        self.cupos = self.cupos - 1

    def liberar_cupo(self):
        self.cupos = self.cupos + 1

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["nombre"] = self.nombre
        datos["codigo"] = self.codigo
        datos["creditos"] = self.creditos
        datos["cupos"] = self.cupos
        return datos

    def etiqueta(self):
        texto = f"{self.codigo} · {self.nombre} · {self.creditos} créditos · cupos {self.cupos}"
        if not self.hay_cupo():
            texto = texto + " ⚠ sin cupo"
        return texto


# =====================================================================
# MATRÍCULA  (equivale a Venta)
# Une un estudiante con una materia. Guarda solo los ids, no copias.
# =====================================================================
class Matricula(ModeloBase):

    def __init__(self, id_registro, estudiante_id, materia_id, periodo,
                 nota=None, fecha=""):
        super().__init__(id_registro)
        self.estudiante_id = int(estudiante_id)
        self.materia_id = int(materia_id)
        self.periodo = periodo            # ej. "2026-1"

        # La nota es None mientras el profesor no la haya registrado
        if nota is None:
            self.nota = None
        else:
            self.nota = float(nota)

        # Si no me dan fecha, uso la de hoy
        if fecha == "":
            self.fecha = date.today().isoformat()
        else:
            self.fecha = fecha

    def esta_aprobada(self):
        if self.nota is None:
            return False
        return self.nota >= Materia.NOTA_APROBACION

    # El estado NO se guarda: se calcula cada vez, así nunca queda desactualizado
    def estado(self):
        if self.nota is None:
            return "Pendiente"
        if self.esta_aprobada():
            return "Aprobado"
        return "Reprobado"

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["estudiante_id"] = self.estudiante_id
        datos["materia_id"] = self.materia_id
        datos["periodo"] = self.periodo
        datos["nota"] = self.nota
        datos["fecha"] = self.fecha
        return datos

    def etiqueta(self):
        if self.nota is None:
            nota = "sin nota"
        else:
            nota = f"nota {self.nota:g}"
        return (f"{self.periodo} · estudiante {self.estudiante_id} · "
                f"materia {self.materia_id} · {nota} · {self.estado()}")
